<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Modul 2 - Latihan 2d</title>
	<style>
		.kotak{
			width: 30px;
			height: 30px;
			text-align: center;
			line-height: 30px;
			border:1px solid black;
			float: left;
			margin: 2px;
			color: black;

		}
		.kotak1{
			background-color: #57e65a;
			width: 30px;
			height: 30px;
			text-align: center;
			line-height: 30px;
			border:1px solid black;
			float: left;
			margin: 2px;
			color: black;
		}
		.ganjil {
			background-color: black;
			color: #fff;
		}
		.genap {
			background-color: #57e65a;
		}
	</style>
</head>
<body>

	<?php
	for ($i = 1; $i <= 5; $i++){
		for ($j = 1; $j <= $i; $j++) {
		if($i%2==1){
			print"<div class='kotak'>#$i</div>
				  <div class='kotak1 ganjil'>$j</div>
			      ";
		
		} else {print"<div class='kotak'>#$i</div>
				  <div class='kotak1 genap'>$j</div>
			      ";
		
		}

	}
	echo "<br><br>";
}
	
	?>

</body>
</html>