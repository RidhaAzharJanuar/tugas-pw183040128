<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Modul 2 - Latihan 1</title>
	<style>
		.tablekosong{
			height: 8px;
			width:  1px solid;
		}
	</style>
</head>
<body>
	<table border="1" cellpadding="10" cellspacing="0">
		<tr>
			<th>Kolom 1</th>
			<th>Kolom 2</th>
			<th>Kolom 3</th>
			<th>Kolom 4</th>
			<th>Kolom 5</th>
		</tr>

		<?php

		for ($i = 1; $i <= 5; $i++){
			echo "<tr>";
			if ($i % 2 == 1) {
				for ($j= 1; $j <=5; $j++) {
					echo "<td>Baris $i, Kolom $j</td>";
				}
			}else {
				for ($j =1; $j<=5; $j++) {
					echo "<td class = 'tablekosong'></td>";
				}
			} echo"</tr>";
		}



		?>















	</table>
</body>
</html>



