<!DOCTYPE html>
<html>
<head>
	<title>Tugas 1</title>
	<style>
		.kotak {
			width:32px;
			height: 32px;
			text-align: center;
			line-height: 30px;
			display: inline-block;
			margin: 1px;
			background-color: black;
		}
		.putih {
			width: 30px;
			height: 30px;
			background-color: white;
			border: 1px solid black;
			display: inline-block;
		}
		.clear {
			clear: both;
		}
		
	</style>
</head>
<body>

	<?php
	
	for ( $i = 1; $i <= 5; $i++) {
		for ($j = 1; $j <= 5; $j++){
			if ($i % 2 == 1){
				if($j % 2 == 1) {
					//ganjil
					echo "<div class='kotak'></div>";
				} else {
					//genap
					echo "<div class='kotak putih'></div>";
				}
			}else {
				if ($j %2 == 0){
					//ganjil
					echo "<div class='kotak'></div>";
				}
				else{
					//genap 
					echo "<div class='kotak putih'></div>";
				}
			}
		}
		echo "<div class='clear'></div>";
	}			
	
	
	
	?>

</body>
</html>