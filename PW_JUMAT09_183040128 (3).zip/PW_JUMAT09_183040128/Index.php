<!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!-- MyCSS -->
      <link rel="stylesheet" type="text/css" href="css/style.css">

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>

  <nav class="red lighten-4">
    <div class="container">
      <div class="nav-wrapper">
        <a href="#!" class="brand-logo">1 & 2</a>
        <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        <ul class="right hide-on-med-and-down">
           <li><a href="Pertemuan1/Latihan1a.php">Latihan1a</a></li>
            <li><a href="Pertemuan1/Latihan1b.php">Latihan1b</a></li>
            <li><a href="Pertemuan1/Latihan1c.php">Latihan1c</a></li>
            <li><a href="Pertemuan2/Latihan/Latihan2a.php">Latihan2a</a></li>
            <li><a href="Pertemuan2/Latihan/Latihan2b.php">Latihan2b</a></li>
            <li><a href="Pertemuan2/Latihan/Latihan2c.php">Latihan2c</a></li>
            <li><a href="Pertemuan2/Latihan/Latihan2d.php">Latihan2d</a></li>
            <li><a href="Pertemuan2/Tugas/Tugas1.php">Tugas1</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <ul class="sidenav" id="mobile-demo">
    <li><a href="Pertemuan1/Latihan1a.php">Latihan1a</a></li>
    <li><a href="Pertemuan1/Latihan1b.php">Latihan1b</a></li>
    <li><a href="Pertemuan1/Latihan1c.php">Latihan1c</a></li>
    <li><a href="Pertemuan2/Latihan/Latihan2a.php">Latihan2a</a></li>
    <li><a href="Pertemuan2/Latihan/Latihan2b.php">Latihan2b</a></li>
    <li><a href="Pertemuan2/Latihan/Latihan2c.php">Latihan2c</a></li>
    <li><a href="Pertemuan2/Latihan/Latihan2d.php">Latihan2d</a></li>
    <li><a href="Pertemuan2/Tugas/Tugas1.php">Tugas1</a></li>
  </ul>



  <div class="slider">
    <ul class="slides">
      <li>
        <img src="img/slider/1.png"> <!-- random image -->
        <div class="caption left-align">
          <h3>Pemrograman WEB</h3>
          <h5 class="light grey-text text-lighten-3">Pertemuan 1 & Pertemuan 2</h5>
        </div>
      </li>
      <li>
        <img src="img/slider/2.png"> <!-- random image -->
        <div class="caption right-align">
          <h3>Peertemuan 2</h3>
          <h5 class="light grey-text text-lighten-3">For, if-else</h5>
        </div>
      </li>
      <li>
        <img src="img/slider/3.png"> <!-- random image -->
        <div class="caption right-align">
          <h3>Ridha Azhar Januar</h3>
          <h5 class="light grey-text text-lighten-3">183040128</h5>
        </div>
      </li>
      <li>
        <img src="img/slider/4.png"> <!-- random image -->
        <div class="caption center-align">
          <h3>Universitas Pasundan</h3>
          <h5 class="light grey-text text-lighten-3">Teknik Informatikan</h5>
        </div>
      </li>
    </ul>
  </div>

      <!--JavaScript at end of body for optimized loading-->
      <script type="text/javascript" src="js/materialize.min.js"></script>
      <script type="text/javascript">
      
        var myNav = document.querySelector('.sidenav');
        M.Sidenav.init(myNav, {
          edge : 'right',
          inDuration : 1000,
          outDuration : 1000,
          draggable : true
        }); 


        var mySlider = document.querySelector('.slider');
        M.Slider.init(mySlider, {
          indicators : false,
          height : 600,
          duration : 600,
          interval : 2000
        });

        const parallax = document.querySelectorAll('.parallax');
        M.Parallax.init(parallax);
          

      </script>



    </body>
  </html>