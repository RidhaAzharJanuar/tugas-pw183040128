<?php

$a = "Bakso";
$b = "Bulat";

echo $a . " itu " . $b . ", $b itu " . $a;





?>