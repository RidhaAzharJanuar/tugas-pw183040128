<!DOCTYPE html>
<html>
<head>
	<title>Latihan 1c</title>

	<style>
		.container {
			width: 158px;
			height: 158px;
			border: 1px solid black;
		}
		.kotak1 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			display: inline-block;
			text-align: center;
			margin-top :12px;
		}
		.kotak2 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			display: inline-block;
			text-align: center;
		}
		.kotak3 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			display: inline-block;
			text-align: center;
		}
		.kotak4 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			display: inline-block;
			text-align: center;
		}

		.kotak5 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			display: inline-block;
			text-align: center;
		}
		.kotak6 {
			width: 35px;
			height: 35px;
			border: 1px solid black;
			margin: 5px;
			text-align: center;
		}
		
		
	</style>



</head>
<body>

	<?php

	$a = "A";
	$b = "B";
	$c = "C";

	echo "<div class='container'>"; 
		
	echo "<div class='kotak1'>$a</div>";
	echo "<div class='kotak2'>$a</div>";
	echo "<div class='kotak3'>$a</div>";
	echo "<div class='kotak4'>$b</div>";
	echo "<div class='kotak5'>$b</div>";
	echo "<div class='kotak6'>$c</div>";

	echo "</div>";	


	?>



</body>
</html>