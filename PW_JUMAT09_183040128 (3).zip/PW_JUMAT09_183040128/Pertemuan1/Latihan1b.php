<?php

$a = 15;
echo "Aku adalah angka $a";
echo "</br>";
echo "Jika aku dikali 5 maka, aku sekarang bernilai " .$a*=5;
echo "</br>";
echo "Jika aku dibagi 3 maka, aku sekarang bernilai " .$a/=3;
echo "</br>";
echo "Jika aku dikurang 30 maka, aku sekarang bernilai " .$a-=30;
echo "</br>";
echo "Jika aku ditambah 10 maka, aku sekarang bernilai " .$a+=10;


?>